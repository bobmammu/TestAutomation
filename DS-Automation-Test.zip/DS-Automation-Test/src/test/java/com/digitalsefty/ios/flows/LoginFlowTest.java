package com.digitalsefty.ios.flows;/*
 * Copyright 2014-2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 * http://aws.amazon.com/apache2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */


import com.digitalsefty.ios.base.BaseTest;
import com.digitalsefty.ios.pages.LoginPage;
import com.digitalsefty.ios.pages.MyFootprintPage;
import io.appium.java_client.MobileElement;
import org.openqa.selenium.By;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import com.digitalsefty.ios.util.CommonUtil;

/**
 * Tests for a login page
 */
public class LoginFlowTest extends BaseTest {



    @Override
    public String getName() {
        return "Login Page";
    }

    @BeforeTest
    public void setUpPage() {

    }

  // @Test
    public void splashScreenSwipe() throws InterruptedException {

//        if(!driver.findElements(By.name("Allow")).isEmpty()) {
//        MobileElement el0 = (MobileElement) driver.findElementByXPath("//XCUIElementTypeButton[@name=\"Allow\"]");
//            el0.click();
//        }

       CommonUtil.swipeRightToLeft(driver);
       CommonUtil.swipeRightToLeft(driver);
       CommonUtil.swipeRightToLeft(driver);
       CommonUtil.swipeLeftToRight(driver);
       CommonUtil.swipeLeftToRight(driver);
       CommonUtil.swipeLeftToRight(driver);

       login();

    }


    public void login() throws InterruptedException {


        LoginPage.login();

        MyFootprintPage.clickViewDetailsOnResultCard();
        Thread.sleep(2000);
//        MenuPage.clickMenu();
//
//        MenuPage.closeMenu();
//        MenuPage.clickAccounts();
//        MenuPage.closeMenu();
//        MenuPage.clickHome();
//        MenuPage.closeMenu();
//        MenuPage.clickPersonalData();
//        MenuPage.closeMenu();

    }


}