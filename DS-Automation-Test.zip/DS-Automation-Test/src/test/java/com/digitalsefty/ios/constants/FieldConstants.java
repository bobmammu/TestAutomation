package com.digitalsefty.ios.constants;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class FieldConstants {

    public static String STRING_BLANK ="";
    public static String STRING_SINGLE_CHARACTER="J";
    public static String STRING_MORE_THAN_FOURTY_CHARACTER ="abcdefghijklmnopqrstuvwxyzabcdefghijklmno";
    public static String STRING_WITH_SPACE="J J";

    public static String STRING_CAMEL_CASE = "DeAndre";
    public static String STRING_CAMEL_CASE_APOSTROPHE = "De'Andre";
    public static String STRING_HYPHENATED = "De-Andre";
    public static String STRING_SPECIAL_CHARACTER = "Jo$hn";
    public static String STRING_REGULAR_CHARACTER = "Smith";
    public static String EMAIL_WITHOUT_ATTHERATE= "johnsmith.com";
    public static String EMAIL_WITHOUT_DOMAIN= "john@yahoo";
    public static String EMAIL_WITH_SPACE= "john @yahoo.com";
    public static String EMAIL_WITH_MULTIPLE_ATTHERATE= "john@smith@yahoo.com";
    public static List<Integer> PASSWORD_CHARACRER_ARRAY= Arrays.asList( 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44,45,46
            ,47,58,59,60,61,62,63,64,91,92,93,94,95,96,123,124,125,126);

}