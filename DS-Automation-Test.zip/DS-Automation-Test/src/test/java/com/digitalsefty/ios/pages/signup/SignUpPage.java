package com.digitalsefty.ios.pages.signup;


import com.digitalsefty.ios.constants.FieldConstants;
import com.digitalsefty.ios.model.SignUpModel;
import com.digitalsefty.ios.pages.BasePage;
import com.digitalsefty.ios.util.VerificationCodeExtractor;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.ios.IOSDriver;
import org.openqa.selenium.Keys;
import org.springframework.util.Assert;

import java.util.Date;

/**
 * Created by ythoo on 8/29/17.
 */
public class SignUpPage extends BasePage{

    public static String FIRST_NAME_ELEMENT = "//XCUIElementTypeApplication[@name=\"DigitalSafety\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeTextField[1]";
    public static String LAST_NAME_ELEMENT = "//XCUIElementTypeApplication[@name=\"DigitalSafety\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeTextField[2]";
    public static String EMAIL_ID_ELEMENT = "//XCUIElementTypeApplication[@name=\"DigitalSafety\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeTextField";
    public static String PHONE_NUMBER_ELEMENT = "//XCUIElementTypeApplication[@name=\"DigitalSafety\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeTable/XCUIElementTypeCell/XCUIElementTypeTextField";
    public static String CREATE_PASSWORD_ELEMENT = "//XCUIElementTypeApplication[@name=\"DigitalSafety\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeTable/XCUIElementTypeCell/XCUIElementTypeSecureTextField[2]";
    public static String CONFIRM_PASSWORD_ELEMENT = "//XCUIElementTypeApplication[@name=\"DigitalSafety\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeTable/XCUIElementTypeCell/XCUIElementTypeSecureTextField[4]";
    public static String ZIPCODE_ELEMENT="//XCUIElementTypeApplication[@name=\"DigitalSafety\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeTable/XCUIElementTypeCell/XCUIElementTypeTextField";
    public static String VERIFY_CODE_ELEMENT="//XCUIElementTypeApplication[@name=\"DigitalSafety\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther[1]/XCUIElementTypeTextField";
    public static String GET_STARTED_BUTTON = "GET STARTED";
    public static String RETURN_BUTTON = "Return";
    public static String NEXT_BUTTON = "NEXT";
    public static String ACCEPT_BUTTON = "ACCEPT";
    public static String START_SCAN_BUTTON ="START SCAN FOR ";

    public static String ERROR_FIRSTNAME_BLANK="The screen appears to be blank. Please enter your first name.";
    public static String ERROR_LASTNAME_BLANK="The screen appears to be blank. Please enter your last name.";
    public static String ERROR_EMAIL_FORMAT="That doesn't look correct. Email format should be xyz@abc.def.";
    private SignUpModel signUpModel;

    public SignUpPage(IOSDriver driver) {
        super(driver);
        Date testDate= new Date();
        String uniqueEmail= "test"+testDate.getTime()+"@gmails.com";

        signUpModel = new SignUpModel("Digital","Safety",uniqueEmail,"2243260211","Allstate@123","60016");
    }


    public void signUp1() throws InterruptedException {

        setElement(FIRST_NAME_ELEMENT,signUpModel.getFirstName());
        setElement(LAST_NAME_ELEMENT,signUpModel.getLastName());
        clickButtonIfExists(NEXT_BUTTON);

    }

    public void signUp2() throws InterruptedException {

        setElement(EMAIL_ID_ELEMENT,signUpModel.getEmailAddress());
        clickButtonIfExists(NEXT_BUTTON);

    }

    public void signUp3() throws InterruptedException {

        clickButtonIfExists(ACCEPT_BUTTON);

    }

    public void signUp4() throws InterruptedException {

        setElement(CREATE_PASSWORD_ELEMENT,signUpModel.getCreatePassword());
        setElement(CONFIRM_PASSWORD_ELEMENT,signUpModel.getCreatePassword());
        clickButtonIfExists(NEXT_BUTTON);

    }
    public void signUp5() throws InterruptedException {

        setElement(ZIPCODE_ELEMENT,signUpModel.getZipCode());
        clickButtonIfExists(NEXT_BUTTON);

    }
    public void signUp6() throws InterruptedException {



        setElement(PHONE_NUMBER_ELEMENT,signUpModel.getPhoneNumber());
        clickButtonIfExists(NEXT_BUTTON);

    }

    public void signUp7(Long timestamp) throws InterruptedException {
        VerificationCodeExtractor verificationCodeExtractor = new VerificationCodeExtractor();
        setElement(VERIFY_CODE_ELEMENT,verificationCodeExtractor.getVerificationCode(timestamp));
        clickButtonIfExists(NEXT_BUTTON);

    }

    public void signUp8() throws InterruptedException {

        Thread.sleep(1000);
        clickButtonIfExists(START_SCAN_BUTTON+signUpModel.getEmailAddress().toUpperCase());

    }


    public void signUp1_EnterLastNameNoFirstName_ShouldGiveError() throws InterruptedException{

        setElement(FIRST_NAME_ELEMENT,"");
        setElement(LAST_NAME_ELEMENT,signUpModel.getLastName());
        clickButtonIfExists(NEXT_BUTTON);
        Assert.isTrue(!checkIfEnabled(NEXT_BUTTON));

    }
    public void signUp1_EnterFirstNameNoLastName_ShouldGiveError() throws InterruptedException{

        setElement(FIRST_NAME_ELEMENT,signUpModel.getFirstName());
        setElement(LAST_NAME_ELEMENT,"");
        clickButtonIfExists(NEXT_BUTTON);
        Assert.isTrue(!checkIfEnabled(NEXT_BUTTON));

    }

    public void signUp1_EnterFirstNameWithMoreThanFourtyCharacters() throws InterruptedException {
        setElement(LAST_NAME_ELEMENT,signUpModel.getLastName());
        Assert.isTrue(setAndGetelement(FIRST_NAME_ELEMENT,FieldConstants.STRING_MORE_THAN_FOURTY_CHARACTER)
                .equals(FieldConstants.STRING_MORE_THAN_FOURTY_CHARACTER.substring(0,40)));
    }

    public void signUp1_EnterLastNameWithMoreThanFourtyCharacters() throws InterruptedException {
        setElement(FIRST_NAME_ELEMENT,signUpModel.getLastName());
        Assert.isTrue(setAndGetelement(LAST_NAME_ELEMENT,FieldConstants.STRING_MORE_THAN_FOURTY_CHARACTER)
                .equals(FieldConstants.STRING_MORE_THAN_FOURTY_CHARACTER.substring(0,40)));
    }


    public void signUp1_EnterFirstNameWithSpecialCharacters() throws InterruptedException {
        Assert.isTrue(setAndcheckElement(FIRST_NAME_ELEMENT,FieldConstants.STRING_SPECIAL_CHARACTER));
        setElement(LAST_NAME_ELEMENT,FieldConstants.STRING_REGULAR_CHARACTER);
        clickButtonIfExists(NEXT_BUTTON);
    }

    public void signUp1_EnterLasttNameWithSpecialCharacters() throws InterruptedException {
        setElement(FIRST_NAME_ELEMENT,FieldConstants.STRING_REGULAR_CHARACTER);
        Assert.isTrue(setAndcheckElement(LAST_NAME_ELEMENT,FieldConstants.STRING_SPECIAL_CHARACTER));
        clickButtonIfExists(NEXT_BUTTON);
    }

    public void signUp1_EnterFirstNameWithSingleCharacters() throws InterruptedException {
        setElement(FIRST_NAME_ELEMENT,FieldConstants.STRING_SINGLE_CHARACTER);
        setElement(LAST_NAME_ELEMENT,FieldConstants.STRING_REGULAR_CHARACTER);
        clickButtonIfExists(NEXT_BUTTON);
        checkIfExists("First Name");
        //XCUIElementTypeStaticText[@name="First Name"]
    }

    public void signUp1_EnterLasttNameWithSinglelCharacters() throws InterruptedException {
        setElement(FIRST_NAME_ELEMENT,FieldConstants.STRING_REGULAR_CHARACTER);
        setElement(LAST_NAME_ELEMENT,FieldConstants.STRING_SINGLE_CHARACTER);
        clickButtonIfExists(NEXT_BUTTON);
        checkIfExists("Last Name");
    }

    //driver.getKeyboard().sendKeys(Keys.DELETE);

    public void signUp1_EnterFirstNameWithOnlySpaces() throws InterruptedException {
        setElement(FIRST_NAME_ELEMENT,FieldConstants.STRING_REGULAR_CHARACTER);
        driver.getKeyboard().sendKeys(Keys.DELETE);
        new TouchAction(driver).longPress(0,0).perform();
        driver.getKeyboard().sendKeys(Keys.ARROW_LEFT);
        driver.getKeyboard().sendKeys(Keys.ARROW_LEFT);
        driver.getKeyboard().sendKeys(Keys.DELETE);
        setElement(LAST_NAME_ELEMENT,FieldConstants.STRING_REGULAR_CHARACTER);
        clickButtonIfExists(NEXT_BUTTON);
        checkIfExists("First Name");
    }

    public void signUp1_EnterLasttNameWithOnlySpaces() throws InterruptedException {
        setElement(FIRST_NAME_ELEMENT,FieldConstants.STRING_REGULAR_CHARACTER);
        setElement(LAST_NAME_ELEMENT,FieldConstants.STRING_WITH_SPACE);
        driver.getKeyboard().sendKeys(Keys.DELETE);
        driver.getKeyboard().sendKeys(Keys.ARROW_RIGHT);
        driver.getKeyboard().sendKeys(Keys.DELETE);
        clickButtonIfExists(NEXT_BUTTON);
        checkIfExists("Last Name");
    }

    public void signUp1_EnterFirstNameWithCamelCase() throws InterruptedException {
        setElement(FIRST_NAME_ELEMENT,FieldConstants.STRING_CAMEL_CASE);
        setElement(LAST_NAME_ELEMENT,FieldConstants.STRING_REGULAR_CHARACTER);
        clickButtonIfExists(NEXT_BUTTON);
    }
    public void signUp1_EnterFirstNameWithApostrophe() throws InterruptedException {
        setElement(FIRST_NAME_ELEMENT,FieldConstants.STRING_CAMEL_CASE_APOSTROPHE);
        setElement(LAST_NAME_ELEMENT,FieldConstants.STRING_REGULAR_CHARACTER);
        clickButtonIfExists(NEXT_BUTTON);
    }

    public void signUp1_EnterFirstNameWithHyphen() throws InterruptedException {
        setElement(FIRST_NAME_ELEMENT,FieldConstants.STRING_HYPHENATED);
        setElement(LAST_NAME_ELEMENT,FieldConstants.STRING_REGULAR_CHARACTER);
        clickButtonIfExists(NEXT_BUTTON);
    }

    public void signUp1_EnterFirstNameWithSpace() throws InterruptedException {
        setElement(FIRST_NAME_ELEMENT,FieldConstants.STRING_WITH_SPACE);
        setElement(LAST_NAME_ELEMENT,FieldConstants.STRING_REGULAR_CHARACTER);
        clickButtonIfExists(NEXT_BUTTON);
    }

    public void signUp2_EnterInvalidEmail() throws InterruptedException {

        setElement(EMAIL_ID_ELEMENT,FieldConstants.EMAIL_WITHOUT_ATTHERATE);
        clickButtonIfExists(NEXT_BUTTON);
        checkIfExists(ERROR_EMAIL_FORMAT);

        setElement(EMAIL_ID_ELEMENT,FieldConstants.EMAIL_WITH_SPACE);
        clickButtonIfExists(NEXT_BUTTON);
        checkIfExists(ERROR_EMAIL_FORMAT);

        setElement(EMAIL_ID_ELEMENT,FieldConstants.EMAIL_WITHOUT_DOMAIN);
        clickButtonIfExists(NEXT_BUTTON);
        checkIfExists(ERROR_EMAIL_FORMAT);

        setElement(EMAIL_ID_ELEMENT,FieldConstants.EMAIL_WITH_MULTIPLE_ATTHERATE);
        clickButtonIfExists(NEXT_BUTTON);
        checkIfExists(ERROR_EMAIL_FORMAT);

    }

    public void signUp4_EnterValidPassword() throws InterruptedException {
        boolean testSuccess= true;
        for (int i : FieldConstants.PASSWORD_CHARACRER_ARRAY) {
            String passwordStr= "Allstate" + Character.toString((char)i)+ "123";
            setElement(CREATE_PASSWORD_ELEMENT, passwordStr);
            setElement(CONFIRM_PASSWORD_ELEMENT, passwordStr);
            Thread.sleep(2);
            if(!checkIfEnabled(NEXT_BUTTON)){
                testSuccess=false;
                System.out.println("Allstate" + Character.toString((char)i)+ "123");
            }
            clearElement(CREATE_PASSWORD_ELEMENT,CONFIRM_PASSWORD_ELEMENT);
        }


        if(!testSuccess){
            Assert.isTrue(false);
        }
 //       checkIfExists("Email/Username");
//
//        setElement(EMAIL_ID_ELEMENT,FieldConstants.EMAIL_WITH_SPACE);
//        clickButtonIfExists(NEXT_BUTTON);
//        checkIfExists("Email/Username");
//
//        setElement(EMAIL_ID_ELEMENT,FieldConstants.EMAIL_WITHOUT_DOMAIN);
//        clickButtonIfExists(NEXT_BUTTON);
//        checkIfExists("Email/Username");
//
//        setElement(EMAIL_ID_ELEMENT,FieldConstants.EMAIL_WITH_MULTIPLE_ATTHERATE);
//        clickButtonIfExists(NEXT_BUTTON);
//        checkIfExists("Email/Username");

    }


    public void verifyAlert(){
        clickElement("//XCUIElementTypeButton[@name=\"GET STARTED\"]");
        clickElement("//XCUIElementTypeAlert[@name=\"Alert!\"]");
        clickElement("//XCUIElementTypeButton[@name=\"OK\"]");


    }
    public void clickOnGetStarted() {
        MobileElement el3 = (MobileElement) driver.findElementByAccessibilityId("getStarted");
        el3.click();
    }

}
