package com.digitalsefty.ios.flows;

import com.digitalsefty.ios.base.BaseTest;
import com.digitalsefty.ios.pages.EmailProviderPage;
import com.digitalsefty.ios.pages.GmailLoginPage;
import com.digitalsefty.ios.pages.MyFootprintPage;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;


public class GmailScanFlow extends BaseTest {

    public static final By NEXT_BUTTON_BY = By.id("NEXT");
    public static final By VIEW_FOOTPRINT_TEXT_BY = By.id("We help you see your Digital Footprint");

    @Override
    public String getName() {
        return "Gmail Scan flow";
    }

    @BeforeTest
    public void setUpPage() {

    }


    @BeforeClass
    public void signup(){
        try {
            new SignUpFlowTest().signUp_ShouldSuccessfullySignUp();
            waitTillFindElement(VIEW_FOOTPRINT_TEXT_BY);
            waitTillFindElement(NEXT_BUTTON_BY).click();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }catch (NoSuchElementException e) {
        e.printStackTrace();
    }
    }

   // @Test
    public static void gmailScan() throws InterruptedException {




        EmailProviderPage.selectGmail();

        GmailLoginPage.signInGmail();

        MyFootprintPage.verifyFootprint();

        MyFootprintPage.moveToScanResults();

        MyFootprintPage.clickViewDetailsOnResultCard();

       // (new TouchAction(BaseTest.driver)).tap(255, 620).perform();
    }
}
