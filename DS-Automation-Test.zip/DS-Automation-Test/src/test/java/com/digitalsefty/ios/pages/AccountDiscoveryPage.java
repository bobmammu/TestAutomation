package com.digitalsefty.ios.pages;

import com.digitalsefty.ios.base.BaseTest;
import io.appium.java_client.MobileElement;

public class AccountDiscoveryPage {


    public static void nextActionButton() throws InterruptedException{

        MobileElement el5 = (MobileElement) BaseTest.driver.findElementByAccessibilityId("NEXT");
        el5.click();

    }
}
