package com.digitalsefty.ios.flows;

import com.digitalsefty.ios.base.BaseTest;
import com.digitalsefty.ios.pages.LoginPage;
import io.appium.java_client.MobileElement;
import org.openqa.selenium.By;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

/**
 * Created by apavn on 9/21/17.
 */
public class ToastTest extends BaseTest {

    public static final By NEXT_BUTTON_BY = By.id("NEXT");


   // @Test
    public void login_shouldShowToast() throws InterruptedException {
        new LoginPage().loginWith("a1@test.com","Allstate@123");
//        waitTillFindElement(NEXT_BUTTON_BY).click();
//
//        EmailProviderPage.selectGmail();
//
//        GmailLoginPage.signInGmail();

        MobileElement toastElement = waitTillFindElement(By.id("FOOTPRINT UPDATED"),20);


    }

    public String getName() {
        return "Toast-Test";
    }

    @BeforeTest
    public void setUpPage() {

    }
}
