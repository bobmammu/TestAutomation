package com.digitalsefty.ios.pages;

import com.digitalsefty.ios.base.BaseTest;
import org.openqa.selenium.By;
import io.appium.java_client.MobileElement;

public class MyFootprintPage {

    public static void verifyFootprint() throws InterruptedException{

        while(BaseTest.driver.findElements(By.name("VIEW FOOTPRINT")).isEmpty()){
            Thread.sleep(1000);
        }


    }

    public static void moveToScanResults() throws InterruptedException{
        MobileElement el21 = (MobileElement) BaseTest.driver.findElementByAccessibilityId("VIEW FOOTPRINT");
        el21.click();
    }

    public static void clickViewDetailsOnResultCard() throws InterruptedException {
        MobileElement el21 = (MobileElement) BaseTest.driver.findElementByAccessibilityId("View Details");
        el21.click();

    }
}
