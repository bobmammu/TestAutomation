package com.digitalsefty.ios.pages;

import com.digitalsefty.ios.base.BaseTest;
import com.digitalsefty.ios.util.CommonUtil;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import com.digitalsefty.ios.model.SignUpModel;

/**
 * Created by ythoo on 8/29/17.
 */
public class SignUpPage {

    private static String FIRST_NAME_ELEMENT = "//XCUIElementTypeApplication[@name=\"DigitalSafety\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeTable/XCUIElementTypeCell[2]/XCUIElementTypeTextField";
    private static String LAST_NAME_ELEMENT = "//XCUIElementTypeApplication[@name=\"DigitalSafety\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeTable/XCUIElementTypeCell[3]/XCUIElementTypeTextField";
    private static String EMAIL_ID_ELEMENT = "//XCUIElementTypeApplication[@name=\"DigitalSafety\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeTable/XCUIElementTypeCell[4]/XCUIElementTypeTextField";
    private static String PHONE_NUMBER_ELEMENT = "//XCUIElementTypeApplication[@name=\"DigitalSafety\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeTable/XCUIElementTypeCell[5]/XCUIElementTypeTextField";
    private static String CREATE_PASSWORD_ELEMENT = "//XCUIElementTypeApplication[@name=\"DigitalSafety\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeTable/XCUIElementTypeCell[6]/XCUIElementTypeSecureTextField";
    private static String CONFIRM_PASSWORD_ELEMENT = "//XCUIElementTypeApplication[@name=\"DigitalSafety\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeTable/XCUIElementTypeCell[7]/XCUIElementTypeSecureTextField";
    private static String GET_STARTED_BUTTON = "GET STARTED";
    private static String RETURN_BUTTON = "Return";


    public void signUp(SignUpModel signUpModel) throws InterruptedException {


        clickButtonIfExists(RETURN_BUTTON);
      //  verifyAlert();

        setElement(FIRST_NAME_ELEMENT,signUpModel.getFirstName());
        setElement(LAST_NAME_ELEMENT,signUpModel.getLastName());

        setElement(EMAIL_ID_ELEMENT,signUpModel.getEmailAddress());
       // System.out.println(uniqueEmail);
        setElement(PHONE_NUMBER_ELEMENT,signUpModel.getPhoneNumber());
        setElement(CREATE_PASSWORD_ELEMENT,signUpModel.getCreatePassword());
        setElement(CONFIRM_PASSWORD_ELEMENT,signUpModel.getCreatePassword());

        clickButtonIfExists(RETURN_BUTTON);

        CommonUtil.swipeBottomToTop(BaseTest.driver);


        clickButton(GET_STARTED_BUTTON);


        //TermsAndConditionPage.testBackButton();
      //  clickButton(GET_STARTED_BUTTON);


    }



    public void verifyAlert(){
        clickElement("//XCUIElementTypeButton[@name=\"GET STARTED\"]");
        clickElement("//XCUIElementTypeAlert[@name=\"Alert!\"]");
        clickElement("//XCUIElementTypeButton[@name=\"OK\"]");


    }
    //Keyboard return click
    private void clickButtonIfExists(String buttonName){
        if(!BaseTest.driver.findElements(MobileBy.ByAccessibilityId.AccessibilityId(buttonName)).isEmpty()) {
            MobileElement el2 = (MobileElement) BaseTest.driver.findElementByAccessibilityId(buttonName);
            el2.click();
        }
    }

    private MobileElement getElementByXPath(String elementStr){

        return BaseTest.driver.findElementByXPath(elementStr);

    }

    private void setElement(String elementStr, String elementValue){

        MobileElement  mobileElement = getElementByXPath(elementStr);
        mobileElement.sendKeys(elementValue);

    }

    private void clickElement(String elementStr){

        MobileElement  mobileElement = getElementByXPath(elementStr);
        mobileElement.click();

    }

    private MobileElement getButton(String buttonName){

       return BaseTest.driver.findElementByAccessibilityId(buttonName);
    }

    private void clickButton(String buttonName){

        getButton(buttonName).click();

    }

}
