package com.digitalsefty.ios.pages;

import com.digitalsefty.ios.base.BaseTest;
import io.appium.java_client.MobileElement;
import org.openqa.selenium.By;

public class HotmailMSNPage {


    public static void signInHotmailMSN() {

        if(!BaseTest.driver.findElements(By.name("Use another account")).isEmpty()) {
            MobileElement el1 = (MobileElement) BaseTest.driver.findElementByAccessibilityId("Use another account");
            el1.click();
        }

        MobileElement el2 = (MobileElement) BaseTest.driver.findElementByAccessibilityId("Email or phone");
        el2.click();
        el2.sendKeys("dsafe1338@hotmail.com");

        MobileElement el3 = (MobileElement) BaseTest.driver.findElementsByXPath("//XCUIElementTypeButton[@name=\"Sign in\"] ").get(0);
        el3.click();

        if(!BaseTest.driver.findElements(By.xpath("//XCUIElementTypeSecureTextField[@name=\"Enter password\"]")).isEmpty()) {
            MobileElement el4 = (MobileElement) BaseTest.driver.findElementsByXPath("//XCUIElementTypeSecureTextField[@name=\"Enter password\"]").get(0);
            el4.click();
        }

        if(!BaseTest.driver.findElements(By.xpath("//XCUIElementTypeButton[@name=\"Sign in\"]")).isEmpty()) {

            MobileElement el5 = (MobileElement) BaseTest.driver.findElementsByXPath("//XCUIElementTypeButton[@name=\"Sign in\"]").get(0);
            el5.click();

        }

        MobileElement el6 = (MobileElement) BaseTest.driver.findElementsByXPath("//XCUIElementTypeButton[@name=\"Yes\"]").get(0);
        el6.click();


    }
}
