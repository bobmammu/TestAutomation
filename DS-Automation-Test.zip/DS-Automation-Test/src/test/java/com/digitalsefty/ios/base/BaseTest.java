package com.digitalsefty.ios.base;/*
 * Copyright 2014-2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 * http://aws.amazon.com/apache2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */


import com.digitalsefty.ios.TestConfigration;
import com.google.common.base.Function;
import io.appium.java_client.MobileElement;
import io.appium.java_client.ios.IOSDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;

import java.net.MalformedURLException;
import java.util.concurrent.TimeUnit;

/**
 * An abstract com.digitalsefty.ios.base for all of the Android tests within this package
 *
 * Responsible for setting up the Appium test Driver
 */
public abstract class BaseTest {
    /**
     * Make the driver static. This allows it to be created only once
     * and used across all of the test classes.
     */
    public static IOSDriver<MobileElement> driver;

    /**
     * This allows the navigation to work within the app.
     * The category name is returned so we can navigate to it from the navigation
     * drawer.
     *
     * @return The name of the Android category
     */
    public abstract String getName();



    /**
     * Method to initialize the test's page
     */
    @BeforeTest
    public abstract void setUpPage();

    /**
     * This method runs before any other method.
     *
     * Appium follows a client - server com.digitalsefty.ios.model:
     * We are setting up our appium client in order to connect to Device Farm's appium server.
     *
     * We do not need to and SHOULD NOT set our own DesiredCapabilities
     * Device Farm creates custom settings at the server level. Setting your own DesiredCapabilities
     * will result in unexpected results and failures.
     *
     * @throws MalformedURLException An exception that occurs when the URL is wrong
     */
    @BeforeSuite
    public void setUpAppium() throws MalformedURLException {

        driver = TestConfigration.getDriver();
    }

    /**
     * Always remember to quit
     */
    @AfterSuite
    public void tearDownAppium() {
        driver.quit();
    }


    /**
     * Restart the app after every test class to go back to the main
     * screen and to reset the behavior
     */
    @AfterClass
    public void restartApp() {
        driver.resetApp();
    }



    protected MobileElement waitTillFindElement(final By by){


        return new FluentWait<IOSDriver<MobileElement>>(driver)
                .withTimeout(10, TimeUnit.SECONDS)
                .pollingEvery(1,TimeUnit.SECONDS)
                .until(new Function<IOSDriver<MobileElement>, MobileElement>() {
            public MobileElement apply(IOSDriver<MobileElement> input) {
                return input.findElement(by);
            }
        });
        
    }

    protected MobileElement waitTillFindElement(final By by, int timeoutInSec){


        return new FluentWait<IOSDriver<MobileElement>>(driver)
                .withTimeout(timeoutInSec, TimeUnit.SECONDS)
                .pollingEvery(1,TimeUnit.SECONDS)
                .until(new Function<IOSDriver<MobileElement>, MobileElement>() {
                    public MobileElement apply(IOSDriver<MobileElement> input) {
                        return input.findElement(by);
                    }
                });

    }
}