package com.digitalsefty.ios.pages;

import com.digitalsefty.ios.base.BaseTest;
import io.appium.java_client.MobileElement;
import org.openqa.selenium.By;

public class EmailProviderPage {

    public static void selectGmail()  throws InterruptedException{
        Thread.sleep(1000);
        MobileElement el13 = (MobileElement) BaseTest.driver.findElementByXPath("//XCUIElementTypeApplication[@name=\"DigitalSafety\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeCollectionView/XCUIElementTypeCell[1]");
        el13.click();

        if(!BaseTest.driver.findElements(By.name("No Thanks")).isEmpty()){
            MobileElement el20 = (MobileElement) BaseTest.driver.findElementByAccessibilityId("No Thanks");
            el20.click();
            MobileElement el133 = (MobileElement) BaseTest.driver.findElementByXPath("//XCUIElementTypeApplication[@name=\"DigitalSafety\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeCollectionView/XCUIElementTypeCell[1]");
            el133.click();
        }
    }

    public static void selectHotmail()  throws InterruptedException{
        Thread.sleep(1000);
        MobileElement el13 = (MobileElement) BaseTest.driver.findElementByXPath("//XCUIElementTypeApplication[@name=\"DigitalSafety\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeCollectionView/XCUIElementTypeCell[2]");
        el13. click();

        if(!BaseTest.driver.findElements(By.name("No Thanks")).isEmpty()){
            MobileElement el20 = (MobileElement) BaseTest.driver.findElementByAccessibilityId("No Thanks");
            el20.click();
            MobileElement el133 = (MobileElement) BaseTest.driver.findElementByXPath("//XCUIElementTypeApplication[@name=\"DigitalSafety\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeCollectionView/XCUIElementTypeCell[2]");
            el133.click();
        }
    }

}
