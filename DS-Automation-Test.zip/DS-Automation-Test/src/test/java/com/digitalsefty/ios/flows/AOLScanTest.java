package com.digitalsefty.ios.flows;

import com.digitalsefty.ios.base.BaseTest;
import io.appium.java_client.MobileElement;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

/**
 * Created by apavn on 9/20/17.
 */
public class AOLScanTest extends BaseTest {

    public static final By NEXT_BUTTON_BY = By.id("NEXT");
    public static final By AOL_BUTTON_BY = By.id("AOL");
    public static final By EMAIL_INPUT_BY = By.xpath("//XCUIElementTypeApplication[@name=\"DigitalSafety\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeTable/XCUIElementTypeCell[1]/XCUIElementTypeTextField");
    public static final By PASSWORD_INPUT_BY = By.xpath("//XCUIElementTypeApplication[@name=\"DigitalSafety\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeTable/XCUIElementTypeCell[2]/XCUIElementTypeSecureTextField");
    public static final By ALLOW_ACCESS_BUTTON_BY = By.id("ALLOW ACCESS");
    public static final By VIEW_FOOTPRINT_BUTTON_BY = By.id("VIEW FOOTPRINT");
    public static final By VIEW_FOOTPRINT_TEXT_BY = By.id("We help you see your Digital Footprint");




    public String getName() {
        return "Yahoo-Scan-Test";
    }

    @BeforeTest
    public void setUpPage() {



    }

    @BeforeClass
    public void signup(){
        try {
            new SignUpFlowTest().signUp_ShouldSuccessfullySignUp();
            waitTillFindElement(VIEW_FOOTPRINT_TEXT_BY);
            waitTillFindElement(NEXT_BUTTON_BY).click();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }catch (NoSuchElementException e) {
            e.printStackTrace();
        }
    }

   // @Test
    public void scanUsingAOL_shouldFinish(){


        MobileElement el1 = (MobileElement) waitTillFindElement(AOL_BUTTON_BY);
        el1.click();
        MobileElement el2 = (MobileElement) waitTillFindElement(EMAIL_INPUT_BY);
        el2.sendKeys("dsafe001@aol.com");
        MobileElement el3 = (MobileElement) waitTillFindElement(PASSWORD_INPUT_BY);
        el3.sendKeys("Allstate@123");
        MobileElement el4 = (MobileElement) waitTillFindElement(ALLOW_ACCESS_BUTTON_BY);
        el4.click();
        MobileElement el9 = (MobileElement) waitTillFindElement(VIEW_FOOTPRINT_BUTTON_BY);
        el9.click();


    }
}
