package com.digitalsefty.ios;

public class GetStartedNegativeTest {
}
