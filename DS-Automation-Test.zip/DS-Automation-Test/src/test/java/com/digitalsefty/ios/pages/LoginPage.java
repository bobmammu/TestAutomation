package com.digitalsefty.ios.pages;

import com.digitalsefty.ios.base.BaseTest;
import io.appium.java_client.MobileElement;

public class LoginPage {

    public static String EMAIL_ID_ELEMENT ="//XCUIElementTypeApplication[@name=\"DigitalSafety\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeTable/XCUIElementTypeCell[1]/XCUIElementTypeTextField";
    public static String PASSWORD_ELEMENT = "//XCUIElementTypeApplication[@name=\"DigitalSafety\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeTable/XCUIElementTypeCell[2]/XCUIElementTypeSecureTextField";

    public static void login() throws InterruptedException{

        MobileElement el1 = (MobileElement) BaseTest.driver.findElementByAccessibilityId("L O G I N");
        el1.click();

        MobileElement el2 = (MobileElement) BaseTest.driver.findElementByXPath("//XCUIElementTypeApplication[@name=\"DigitalSafety\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeTable/XCUIElementTypeCell[1]/XCUIElementTypeTextField");
        el2.click();
        el2.clear();
        el2.sendKeys("test1505837953383@gma.com");

        MobileElement el3 = (MobileElement) BaseTest.driver.findElementByXPath("//XCUIElementTypeApplication[@name=\"DigitalSafety\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeTable/XCUIElementTypeCell[2]/XCUIElementTypeSecureTextField");
        el3.sendKeys("Allstate@123");

        MobileElement el4 = (MobileElement) BaseTest.driver.findElementByAccessibilityId("LOGIN");
        el4.click();


    }

    public static void loginWith(String user, String password) throws InterruptedException{

        MobileElement el1 = (MobileElement) BaseTest.driver.findElementByAccessibilityId("L O G I N");
        el1.click();

        MobileElement el2 = (MobileElement) BaseTest.driver.findElementByXPath("//XCUIElementTypeApplication[@name=\"DigitalSafety\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeTable/XCUIElementTypeCell[1]/XCUIElementTypeTextField");
        el2.click();
        el2.clear();
        el2.sendKeys(user);

        MobileElement el3 = (MobileElement) BaseTest.driver.findElementByXPath("//XCUIElementTypeApplication[@name=\"DigitalSafety\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeTable/XCUIElementTypeCell[2]/XCUIElementTypeSecureTextField");
        el3.sendKeys(password);

        MobileElement el4 = (MobileElement) BaseTest.driver.findElementByAccessibilityId("LOGIN");
        el4.click();


    }


    public static void enterCredentials() throws InterruptedException{

        MobileElement el10 = (MobileElement) BaseTest.driver.findElementByXPath("//XCUIElementTypeApplication[@name=\"DigitalSafety\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeTable/XCUIElementTypeCell[2]/XCUIElementTypeSecureTextField");
        el10.sendKeys("Allstate@123");
        MobileElement el12 = (MobileElement) BaseTest.driver.findElementByAccessibilityId("NEXT");
        el12.click();
        Thread.sleep(2000);



    }
}
