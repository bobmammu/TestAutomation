package com.digitalsefty.ios;

import io.appium.java_client.MobileElement;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.remote.MobileCapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import sun.swing.CachedPainter;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

/**
 * Created by apavn on 9/18/17.
 */
public class TestConfigration {

    private static final boolean isRunningOnAppium = true;


    private static final String PORT = "4723";

    private static final String URL_STRING = "http://127.0.0.1:"+PORT+"/wd/hub";

    private static final int INIT_WAIT_IN_SEC = 15;



    public static IOSDriver<MobileElement> getDriver() throws MalformedURLException {
        DesiredCapabilities capabilities = new DesiredCapabilities();

        if(isRunningOnAppium){

            //Appium capability here
            capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, "11.2");
            capabilities.setCapability("noReset", false);
            capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "iPhone 8");
            capabilities.setCapability("platformName",  "iOS");
            capabilities.setCapability("bundleId", "com.adv.dsafe");

        }else {

            //Aws capeblity here

        }

        URL url = new URL(URL_STRING);


        IOSDriver<MobileElement>  driver = new IOSDriver<MobileElement>(url, capabilities);;


        // add ideal wait time
        //Use a higher value if your mobile elements take time to show up
        driver.manage().timeouts().implicitlyWait(INIT_WAIT_IN_SEC, TimeUnit.SECONDS);

        return driver;

    }
}
