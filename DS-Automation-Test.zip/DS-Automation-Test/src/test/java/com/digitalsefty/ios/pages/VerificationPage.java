package com.digitalsefty.ios.pages;

import com.digitalsefty.ios.base.BaseTest;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import com.digitalsefty.ios.util.VerificationCodeExtractor;

public class VerificationPage {
    public static String VERIFICATION_FIELD = "//XCUIElementTypeApplication[@name=\"DigitalSafety\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther[1]/XCUIElementTypeTextField";

    public static void insertVerificationCode(Long currentTimeStamp) throws InterruptedException {
        VerificationCodeExtractor verificationCodeExtractor=new VerificationCodeExtractor();
        (new TouchAction(BaseTest.driver)).tap(43, 267).perform();
        Thread.sleep(10000);
        MobileElement el8= (MobileElement) BaseTest.driver.findElementByXPath(VERIFICATION_FIELD);
        el8.sendKeys(verificationCodeExtractor.getVerificationCode(currentTimeStamp));

    }

    public static void clickNext(){
        MobileElement el9 = (MobileElement) BaseTest.driver.findElementByAccessibilityId("NEXT");
        el9.click();
    }
}
