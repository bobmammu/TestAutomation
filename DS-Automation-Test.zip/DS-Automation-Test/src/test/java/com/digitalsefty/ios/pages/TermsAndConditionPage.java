package com.digitalsefty.ios.pages;

import com.digitalsefty.ios.base.BaseTest;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;

public class TermsAndConditionPage {

    public static void testBackButton(){

        (new TouchAction(BaseTest.driver)).tap(14, 41).perform();
    }

    public static void testAcceptButton() {
        //(new TouchAction(BaseTest.driver)).tap(176, 599).perform();
        MobileElement el1 = (MobileElement) BaseTest.driver.findElementByAccessibilityId("ACCEPT");
        el1.click();

    }

}
