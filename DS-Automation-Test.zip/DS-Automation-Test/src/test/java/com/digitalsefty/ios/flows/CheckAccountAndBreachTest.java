package com.digitalsefty.ios.flows;

import com.digitalsefty.ios.pages.LoginPage;
import com.digitalsefty.ios.pages.MenuPage;
import io.appium.java_client.MobileElement;
import org.openqa.selenium.By;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by apavn on 9/21/17.
 */
public class CheckAccountAndBreachTest  extends YahooScanTest{


    public String getName() {
        return "Check-Account-And-Breach-Test";
    }


    @BeforeClass
    @Override
    public void signup() {
        //super.signup();
    }

    @Override
    public void scanUsingYahoo_shouldFinish() {

        signup();
        super.scanUsingYahoo_shouldFinish();

        List<MobileElement> allElements = driver.findElements(By.className("XCUIElementTypeStaticText"));

       MobileElement breachInfoElement = allElements.get(2);

       String infoText = breachInfoElement.getText();

        Pattern pattern = Pattern.compile("[\\d]+");

        pattern.matcher(infoText);

        Matcher m = Pattern.compile("[\\d]+")
                .matcher(infoText);
        int totalAccounts = 0;
        int totalBreaches = 0 ;

        if(m.find())
        {
            totalAccounts = Integer.parseInt(m.group());;
        }

        if(m.find())
        {
            totalBreaches = Integer.parseInt(m.group());;
        }

        System.out.println("Total accounts : "+totalAccounts);
        System.out.println("Total breaches : "+totalBreaches);



        MobileElement el9 = (MobileElement) waitTillFindElement(VIEW_FOOTPRINT_BUTTON_BY,240);

        el9.click();




    }

   // @Test
    public void login_shouldHaveIdenticalNumberOfTotalAccountAndListingSize() throws InterruptedException {
        new LoginPage().loginWith("a1@test.com","Allstate@123");


        //Thread.sleep(5);

        //MobileElement toastElement = waitTillFindElement(By.name("FOOTPRINT UPDATED"),20);


        Thread.sleep(20);

        MenuPage.clickMenu();

        MenuPage.clickAccounts();



        MobileElement accountTable = waitTillFindElement(By.className("XCUIElementTypeTable"));

        MobileElement totalAccountCell = waitTillFindElement(By.className("XCUIElementTypeCell"));



        MobileElement totalAccountText = totalAccountCell.findElements(By.className("XCUIElementTypeStaticText")).get(0);


        int totalAccount = Integer.parseInt(totalAccountText.getText());


        String cellXpath = "//XCUIElementTypeApplication[@name=\"DigitalSafety\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeTable/XCUIElementTypeStaticText[%d]";


        for(int i = 0 ; i< totalAccount; i++){

            driver.findElement(By.xpath(String.format(cellXpath,(i+1))));
        }

        List<MobileElement> accountList = accountTable.findElements(By.className("XCUIElementTypeStaticText"));


        //Assert.assertEquals(accountList.size(),totalAccount);



    }




}
