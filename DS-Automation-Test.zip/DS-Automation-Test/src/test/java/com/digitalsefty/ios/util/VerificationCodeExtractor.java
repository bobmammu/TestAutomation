package com.digitalsefty.ios.util;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import org.jsoup.Connection;
import org.jsoup.Jsoup;

import java.io.IOException;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class VerificationCodeExtractor {

    public String getVerificationCode(Long timeStamp){
        String GOOGLE_REFRESH_TOKEN="1/eLT4VI4vwx6zKhme47Hvlm790P5Mh-Ra6_pGVJ8rMXU";
        String GOOGLE_AUTH_URL="https://www.googleapis.com/oauth2/v4/token?client_secret=2EfRjsmRRu40wVoTW1f6UT65&grant_type=refresh_token" +
                "&refresh_token="+GOOGLE_REFRESH_TOKEN+"&client_id=200903543205-mkiig2kpf4a5g71fvqs2mcia437anfm2.apps.googleusercontent.com";

        String GOOGLE_AUTH_TOKEN="ya29.GlvEBMLlWVR6hxIibrZqgaWKlXXH2r4obU9bWt30EpRyjLy5R55k0icOsZRF6nGEKO8YB_2ZidGYtyy2w_tHQ3TygRZJQYVKJ3DcqCUvnVth1-jS14k7c7YYlzgS";
        try {
            Connection.Response tokenResponse= Jsoup.connect(GOOGLE_AUTH_URL).ignoreContentType(true)
                    .method(Connection.Method.POST)
                    .header("Content-Type","application/x-www-form-urlencoded")
                    .execute();

            Gson gson = new Gson();
            JsonElement jelem = gson.fromJson(tokenResponse.body().toString(), JsonElement.class);
            JsonObject jobj = jelem.getAsJsonObject();
            GOOGLE_AUTH_TOKEN= jobj.get("access_token").getAsString();
        } catch (IOException e) {
            e.printStackTrace();
        }
    String messageId="";

        try {
            Connection.Response messageResponse= Jsoup.connect("https://www.googleapis.com/gmail/v1/users/me/messages?q=\"after: 2017/11/20 \"").ignoreContentType(true)
                    .method(Connection.Method.GET)
                    .header("Authorization","Bearer "+GOOGLE_AUTH_TOKEN)
                    .header("Content-Type","message/rfc822")
                    .execute();

            Gson gson = new Gson();
            JsonElement jelem = gson.fromJson(messageResponse.body().toString(), JsonElement.class);
            JsonObject jobj = jelem.getAsJsonObject();
            JsonArray messageArray=jobj.getAsJsonArray("messages");
            JsonObject jsonObj=messageArray.get(0).getAsJsonObject();
            messageId=jsonObj.get("id").getAsString();
        } catch (IOException e) {
            e.printStackTrace();
        }


        String  GOOGLE_API_URL="https://www.googleapis.com/gmail/v1/users/dsafe007@gmail.com/messages/"+messageId;


        try {
            Connection.Response postResponse= Jsoup.connect(GOOGLE_API_URL).ignoreContentType(true)
                    .method(Connection.Method.GET)
                    .header("Authorization","Bearer "+GOOGLE_AUTH_TOKEN)
                    .header("Content-Type","message/rfc822")
                    .execute();
            Gson gson = new Gson();
            JsonElement jelem = gson.fromJson(postResponse.body().toString(), JsonElement.class);
            JsonObject jobj = jelem.getAsJsonObject();

            Date dateObj=new Date(jobj.get("internalDate").getAsLong());
            System.out.println("System Time::"+new Date(timeStamp));
            dateObj.after(new Date(timeStamp));
            Pattern p = Pattern.compile("^\\D+(\\d+).*");
            Matcher m = p.matcher(jobj.get("snippet").getAsString());
            if (m.find()) {
                System.out.println(m.group(1));
                return m.group(1);
            }


        } catch (IOException e) {
            e.printStackTrace();
        }
        return "";
    }

    public static void main(String args[]){

        VerificationCodeExtractor nn=new VerificationCodeExtractor();
        nn.getVerificationCode(new Long(1));
    }
}
