package com.digitalsefty.ios.pages;

import com.digitalsefty.ios.base.BaseTest;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;

public class MenuPage {


    public static void clickMenu(){
        MobileElement el6 = (MobileElement) BaseTest.driver.findElementByAccessibilityId("menu button");
        el6.click();
    }

    public static void clickHome(){

        MobileElement el8 = (MobileElement) BaseTest.driver.findElementByAccessibilityId("Home");
        el8.click();
    }
    public static void clickAccounts(){

        MobileElement el7 = (MobileElement) BaseTest.driver.findElementByAccessibilityId("Accounts");
        el7.click();

    }

    public static void clickPersonalData(){

        MobileElement el9 = (MobileElement) BaseTest.driver.findElementByAccessibilityId("Personal Data");
        el9.click();
    }

    public static void closeMenu(){
        (new TouchAction(BaseTest.driver)).tap(44, 46).perform();
    }
}
