package com.digitalsefty.ios.flows;


import com.digitalsefty.ios.base.BaseTest;
import com.digitalsefty.ios.model.SignUpModel;
import com.digitalsefty.ios.pages.GmailLoginPage;
import com.digitalsefty.ios.pages.signup.SignUpPage;
import com.digitalsefty.ios.pages.TermsAndConditionPage;
import com.digitalsefty.ios.pages.VerificationPage;
import io.appium.java_client.MobileElement;
import org.openqa.selenium.By;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.util.Date;

public class SignUpFlowTest extends BaseTest {

    private SignUpPage signUpPage;

    @Override
    public String getName() {
        return "Signup flow";
    }

    @BeforeMethod
    public void setUpPage() {

        signUpPage = new SignUpPage(driver);
        if(!driver.findElements(By.name("Agreed")).isEmpty()) {
            MobileElement el0 = (MobileElement) driver.findElementByXPath("//XCUIElementTypeButton[@name=\"Agreed\"]");
            el0.click();
        }
//        if(!driver.findElements(By.name("GET STARTED")).isEmpty()) {
//            MobileElement el1 = (MobileElement) driver.findElementByXPath("//XCUIElementTypeButton[@label=\"GET STARTED\"]");
//            el1.click();
//        }
        signUpPage.clickOnGetStarted();

    }

    @AfterMethod()
    public void resetApplication(){
        restartApp();
    }

    @Test
    public void signUp_ShouldSuccessfullySignUp() throws InterruptedException {

        Long currentTimeStamp=System.currentTimeMillis();
        signUpPage.signUp1();
        signUpPage.signUp2();
        signUpPage.signUp3();
        signUpPage.signUp4();
        signUpPage.signUp5();
        signUpPage.signUp6();
        Thread.sleep(10000);
        signUpPage.signUp7(currentTimeStamp);
        signUpPage.signUp8();

       GmailLoginPage.signInGmail();
    }

    @Test
    public void signUp1_EnterFirstNameNoLastName_ShouldGiveError() throws InterruptedException {

        signUpPage.signUp1_EnterFirstNameNoLastName_ShouldGiveError();

    }

    @Test
    public void signUp1_EnterLastNameNoFirstName_ShouldGiveError() throws InterruptedException {

        signUpPage.signUp1_EnterLastNameNoFirstName_ShouldGiveError();

    }


    @Test
    public void signUp1_EnterFirstNameWithMoreThanFourtyCharacters() throws InterruptedException {

        signUpPage.signUp1_EnterFirstNameWithMoreThanFourtyCharacters();

    }

    @Test
    public void signUp1_EnterLastNameWithMoreThanFourtyCharacters() throws InterruptedException {

        signUpPage.signUp1_EnterLastNameWithMoreThanFourtyCharacters();

    }

    @Test
    public void signUp1_EnterFirstNameWithSpecialCharacters() throws InterruptedException {

        signUpPage.signUp1_EnterFirstNameWithSpecialCharacters();

    }


    @Test
    public void signUp1_EnterLasttNameWithSpecialCharacters() throws InterruptedException {

        signUpPage.signUp1_EnterLasttNameWithSpecialCharacters();

    }

    @Test
    public void signUp1_EnterFirstNameWithSingleCharacters() throws InterruptedException {

        signUpPage.signUp1_EnterFirstNameWithSingleCharacters();

    }

    @Test
    public void signUp1_EnterLasttNameWithSinglelCharacters() throws InterruptedException {

        signUpPage.signUp1_EnterLasttNameWithSinglelCharacters();

    }

    @Test
    public void signUp1_EnterFirstNameWithOnlySpaces() throws InterruptedException {

        signUpPage.signUp1_EnterFirstNameWithOnlySpaces();

    }

    @Test
    public void signUp1_EnterLasttNameWithOnlySpaces() throws InterruptedException {

        signUpPage.signUp1_EnterLasttNameWithOnlySpaces();

    }

    @Test
    public void signUp1_EnterFirstNameWithCamelCase() throws InterruptedException {

        signUpPage.signUp1_EnterFirstNameWithCamelCase();

    }
    @Test
    public void signUp1_EnterFirstNameWithHyphen() throws InterruptedException {

        signUpPage.signUp1_EnterFirstNameWithHyphen();

    }

    @Test
    public void signUp1_EnterFirstNameWithApostrophe() throws InterruptedException {

        signUpPage.signUp1_EnterFirstNameWithApostrophe();

    }

    @Test
    public void signUp1_EnterFirstNameWithSpace() throws InterruptedException {

        signUpPage.signUp1_EnterFirstNameWithSpace();

    }

    @Test
    public void signUp2_EnterInvalidEmail() throws InterruptedException {
        signUpPage.signUp1();
        signUpPage.signUp2_EnterInvalidEmail();

    }

    @Test
    public void signUp3_EnterValidPassword() throws InterruptedException {

        signUpPage.signUp1();
        signUpPage.signUp2();
        signUpPage.signUp3();
        signUpPage.signUp4_EnterValidPassword();

    }
}
