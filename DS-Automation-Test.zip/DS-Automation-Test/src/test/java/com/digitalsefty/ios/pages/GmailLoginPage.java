package com.digitalsefty.ios.pages;

import com.digitalsefty.ios.base.BaseTest;
import io.appium.java_client.MobileElement;
import org.openqa.selenium.By;

public class GmailLoginPage {


    public static void signInGmail() throws InterruptedException{

       if(!BaseTest.driver.findElements(By.name("Use another account")).isEmpty()) {
            MobileElement el15 = (MobileElement) BaseTest.driver.findElementByAccessibilityId("Use another account");
            el15.click();
        }

        MobileElement el16 = (MobileElement) BaseTest.driver.findElementByAccessibilityId("Email or phone");
        el16.click();
        el16.sendKeys("dsafe1339@gmail.com");
        MobileElement el17 = (MobileElement) BaseTest.driver.findElementByAccessibilityId("NEXT");
        el17.click();
        // BaseTest.driver.findElementsByIosUIAutomation("Enter");
        MobileElement el18 = (MobileElement) BaseTest.driver.findElementByAccessibilityId("Enter your password");
        el18.sendKeys("pass@word");
        MobileElement el19 = (MobileElement) BaseTest.driver.findElementByAccessibilityId("NEXT");
        el19.click();

        int len= BaseTest.driver.findElementsByClassName("XCUIElementTypeButton").size();
//        for(int i=0;i < len;i++) {
//            System.out.println("ByXpath" + BaseTest.driver.findElementsByClassName("XCUIElementTypeButton").get(i).getText());
//        }

        if(!BaseTest.driver.findElements(By.xpath("//XCUIElementTypeButton[@label=\"Enter the city you usually sign in from\"]")).isEmpty()) {
            MobileElement el15 = (MobileElement) BaseTest.driver.findElementByXPath("//XCUIElementTypeButton[@label=\"Enter the city you usually sign in from\"]");
            el15.click();
            if(!BaseTest.driver.findElements(By.name("Enter a city")).isEmpty()) {
                MobileElement el151 = (MobileElement) BaseTest.driver.findElementByAccessibilityId("Enter a city");
                el151.click();
                el151.sendKeys("Glenview,IL");
                MobileElement el191 = (MobileElement) BaseTest.driver.findElementByAccessibilityId("NEXT");
                el191.click();

            }
        }




        Thread.sleep(1000);
        MobileElement el20 = (MobileElement) BaseTest.driver.findElementByAccessibilityId("ALLOW");
        el20.click();
    }
}
